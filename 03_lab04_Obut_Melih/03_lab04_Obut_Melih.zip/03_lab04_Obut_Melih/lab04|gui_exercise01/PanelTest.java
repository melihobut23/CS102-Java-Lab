import javax.swing.*;
import java.awt.*;

/**
 * GUIDemo1
 * @author melih obut
 * @version 31/03/2020
 */ 
public class PanelTest
{
   public static void main( String[] args)
   {

      // constants

      // variables
      MyDrawingPanel  panel;
      //MyDrawingPanel  frame1;
      // program code
      System.out.println( "Start...");
      
      panel = new MyDrawingPanel();
      //frame1 = new MyDrawingPanel(400,500);

      System.out.println( "End.");
   }

}