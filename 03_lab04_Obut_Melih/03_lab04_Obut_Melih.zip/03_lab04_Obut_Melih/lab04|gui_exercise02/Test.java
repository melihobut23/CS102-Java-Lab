import java.util.Scanner;
import java.awt.*;
// import java.awt.Button;


public class Test
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      MyOtherActionListener  f;


      // program code
      System.out.println( "Start...");

      f = new MyOtherActionListener();


      System.out.println( "End.");
   }

}