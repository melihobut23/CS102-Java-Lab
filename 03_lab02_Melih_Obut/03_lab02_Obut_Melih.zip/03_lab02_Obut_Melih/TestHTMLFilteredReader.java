import cs1.SimpleURLReader;
/**
 * Test program of HTLMFilteredReader
 * @author melihobut
 * @date 29.02.2020
 */
public class TestHTMLFilteredReader {
   
   public static void main(String[] args) {
      
      HTMLFilteredReader html = new HTMLFilteredReader("http://www.cs.bilkent.edu.tr/%7Edavid/housman.htm");
      
      System.out.println(html.getPageContents());
      System.out.println(html.getUnfilteredPageContents());
   }
}