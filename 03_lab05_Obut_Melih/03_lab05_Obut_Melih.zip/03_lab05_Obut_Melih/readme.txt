**********************************************
readme.txt for Lab05 ~ cs102 Spring 2019-20 ~
**********************************************

The set of files & folders herein comprise the initial state of the lab assignment.

Lab05.drjava ~ the drjava project file. Run DrJava and from the "Projects" menu, select "Open...", browse to this file and select it.

The "src" folder contains the initial java source code files from which you will build.

The "classes" folder contains the compiled versions of the "src" code. Note: you can use "Projects|Clean Build Directory" to delete the entire folder and all its contents... (don't worry, DrJava will restore it the next time you compile your project!)

The "cs102" folder contains the basic hangman model classes and interfaces. There is no source code for these, only the compiled Java class files. DO NOT delete them!

Important: in order to compile the hangman game demo files, you must have the folder containing the "cs102" folder in your Java classpath. The Lab05.drjava file should do this automatically, but if you are using a different GUI you may need to do something else!

good luck, David.

P.S. If you need help, please ask on the moodle forum.
