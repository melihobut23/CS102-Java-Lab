package hangmangame.extras;

import cs102.hangman.*;
import java.awt.*;
import javax.swing.*;

/**
 * Collection of UI components to form a complete Hangman game. 
 * View components implement IHangmanView, so they can automatically update
 * whenever the hangmanModel associated with changes, changes.
 * Other components are hangman controllers that update the model.
 * @author david
 */
public class HangmanGUIPanel extends JPanel {
   // properties
   
   HangmanModel hm;
   TextFieldControlPanel textField;
   NewGameButtonControl newGame;
   LabelsHangmanView newView;
   GallowsHangmanView newGallows;
   HangmanLetterButtonControls allhangbuttons;
   
   // constructor
   public HangmanGUIPanel( HangmanModel hm) 
   {
      this.hm = hm;
      setPreferredSize( new Dimension( 600, 350) );
      setLayout( new BorderLayout() );
      setBackground(Color.YELLOW);
      textField = new TextFieldControlPanel (hm);
      add (textField, BorderLayout.NORTH);
      
      
      // add newGame button and views here...
      newGame = new NewGameButtonControl(hm);
      hm.addView (newGame);
      add (newGame, BorderLayout.SOUTH);
      
      // add labels here...
      newView = new LabelsHangmanView();
      hm.addView (newView);
      add (newView, BorderLayout.WEST);
      
      // add Hangman  views here...
      newGallows = new GallowsHangmanView(hm);
      hm.addView (newGallows);
      add (newGallows, BorderLayout.CENTER);
      
      // add letter button and views here...
      allhangbuttons = new HangmanLetterButtonControls (hm.getAllLetters());
      hm.addView (allhangbuttons);
      
      // add actionListioner letter button here...
      allhangbuttons.addActionListener (new HangmanLetterButtonsController (hm));
      allhangbuttons.setPreferredSize (new Dimension (130,100));
      
      add (allhangbuttons, BorderLayout.EAST);
   }
   
}
