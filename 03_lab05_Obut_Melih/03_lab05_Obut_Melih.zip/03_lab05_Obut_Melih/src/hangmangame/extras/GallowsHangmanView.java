package hangmangame.extras;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import cs102.hangman.*;
/**
 * View of the man
 * @author melih obut
 */
public class GallowsHangmanView extends JPanel implements IHangmanView{
   // properties
   HangmanModel hangmanModel;
   JLabel lostOrWin;    // lost or win status label
   
   // constructor
   public GallowsHangmanView(HangmanModel hangmanModel){
      this.hangmanModel = hangmanModel;
      lostOrWin = new JLabel();
      setLayout( new BorderLayout());
      setBackground( Color.YELLOW);
      setPreferredSize( new Dimension( 300,400));    // set size of panel 
      add( lostOrWin); 
   }
   
   // updates view
   public void updateView(Hangman hangmanModel)
   {
      repaint();
      if( hangmanModel.isGameOver() && hangmanModel.hasLost()){
         lostOrWin.setText("You Lose");
      }
      else if ( hangmanModel.isGameOver() && !hangmanModel.hasLost()){
         lostOrWin.setText("You Win");
      }
      else if ( !hangmanModel.isGameOver()) {
         lostOrWin.setText("");
      }
   }
   
   // paintComponent() method
   public void paintComponent( Graphics g)
   {
      super.paintComponent(g);
      g.setColor(Color.BLACK);
      // for the tree to hang the man
      g.fillRect( 25, 270, 200, 25);
      g.fillRect( 50, 50, 15, 220);
      g.fillRect( 50, 50, 100, 15);
      g.fillRect( 140, 65, 10, 50);
      
      // if tried letter is incorrect one part of man is gonna  be drawn
      if( hangmanModel.getNumOfIncorrectTries() == 1)
      {
         g.drawOval( 120, 115, 50, 50);
      }
      if( hangmanModel.getNumOfIncorrectTries() == 2)
      {
         g.drawOval( 120, 115, 50, 50);
         g.drawLine( 145, 165, 145, 220);
      }

      if( hangmanModel.getNumOfIncorrectTries() == 3)
      {
         g.drawOval( 120, 115, 50, 50);
         g.drawLine( 145, 165, 145, 220);
         g.drawLine( 145, 170, 120, 190);
      }
  
      if( hangmanModel.getNumOfIncorrectTries() == 4)
      {
         g.drawOval( 120, 115, 50, 50);
         g.drawLine( 145, 165, 145, 220);
         g.drawLine( 145, 170, 120, 190);
         g.drawLine( 145, 170, 170, 190);
      }
      if( hangmanModel.getNumOfIncorrectTries() == 5)
      {
         g.drawOval( 120, 115, 50, 50);
         g.drawLine( 145, 165, 145, 220);
         g.drawLine( 145, 170, 120, 190);
         g.drawLine( 145, 170, 170, 190);
         g.drawLine( 145, 220, 120, 250);
      }

      if( hangmanModel.getNumOfIncorrectTries() == 6)
      {
         g.drawOval( 120, 115, 50, 50);
         g.drawLine( 145, 165, 145, 220);
         g.drawLine( 145, 170, 120, 190);
         g.drawLine( 145, 170, 170, 190);
         g.drawLine( 145, 220, 120, 250);
         g.drawLine( 145, 220, 170, 250);
      }
   }
   
}