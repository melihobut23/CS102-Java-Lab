// ***********************************************
// Lab05 ~ MVC GUI Hangman ~ Spring 2019/20
// David
// ***********************************************

// Compile & Run "hangmangame.ConsoleHangmanDemo"

// Compile & Run "hangmangame.GUIHangmanDemo"

